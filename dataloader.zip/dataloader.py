
from pathlib import Path

config_path = Path(__file__).parent / "config.yaml"
from datetime import timedelta
import pandas as pd


# ============================================================
# CONFIGURATION
# ============================================================

DATASET_DIR = Path("dataset")
OUTPUT_FILE = Path("output.csv")

MINIMUM_BALANCE_DEFAULT = 0.0

OUTPUT_COLUMNS = [
    "request_id",
    "amount_safe_to_pay",
    "affordability_status",
    "recommended_payment_method",
    "payment_plan",
    "earliest_date_for_full_payment",
    "spending_changes_needed",
    "decision_explanation"
]

AFFORDABILITY = {
    "affordable_now",
    "affordable_with_plan",
    "affordable_later",
    "not_affordable"
}

PAYMENT_METHODS = {
    "full_payment",
    "partial_payment",
    "installments",
    "wait",
    "not_recommended"
}


# ============================================================
# DATA LOADER
# ============================================================

class DataLoader:

    def __init__(self, dataset_dir=DATASET_DIR):

        self.dataset_dir = Path(dataset_dir)

        self.requests = self._load("requests.csv")
        self.profiles = self._load("financial_profiles.csv")
        self.events = self._load("financial_events.csv")
        self.exchange_rates = self._load("exchange_rates.csv")
        self.payment_options = self._load(
            "request_payment_options.csv"
        )
        self.messages = self._load("messages.csv")
        self.images = self._load("images.csv")

    def _load(self, filename):

        path = self.dataset_dir / filename

        if not path.exists():
            raise FileNotFoundError(
                f"Missing dataset file: {path}"
            )

        return pd.read_csv(path)

    def get_profile(self, user_id):

        rows = self.profiles[
            self.profiles["user_id"] == user_id
        ]

        if rows.empty:
            return None

        return rows.iloc[0]

    def get_events(self, user_id):

        return self.events[
            self.events["user_id"] == user_id
        ].copy()

    def get_messages(self, user_id, request_id=None):

        rows = self.messages[
            self.messages["user_id"] == user_id
        ].copy()

        if request_id is not None and "request_id" in rows.columns:

            rows = rows[
                rows["request_id"].isna()
                | (rows["request_id"] == request_id)
            ]

        return rows

    def get_images(self, user_id, request_id=None):

        rows = self.images[
            self.images["user_id"] == user_id
        ].copy()

        if request_id is not None and "request_id" in rows.columns:

            rows = rows[
                rows["request_id"].isna()
                | (rows["request_id"] == request_id)
            ]

        return rows

    def get_payment_options(self, request_id):

        return self.payment_options[
            self.payment_options["request_id"] == request_id
        ].copy()


# ============================================================
# FINANCIAL EVENT PROCESSING
# ============================================================

def prepare_events(events):

    events = events.copy()

    if events.empty:
        return events

    # Convert date column
    if "date" in events.columns:
        events["date"] = pd.to_datetime(
            events["date"],
            errors="coerce"
        ).dt.date

    # Convert amounts
    if "amount" in events.columns:
        events["amount"] = pd.to_numeric(
            events["amount"],
            errors="coerce"
        )

    # Remove events without valid dates
    events = events[
        events["date"].notna()
    ]

    return events


# ============================================================
# BALANCE FORECASTER
# ============================================================

class BalanceForecaster:

    def __init__(self, minimum_balance=0):

        self.minimum_balance = float(
            minimum_balance
        )

    def simulate(
        self,
        start_date,
        starting_balance,
        transactions,
        extra_payments=None,
        days=90
    ):

        start_date = pd.to_datetime(
            start_date
        ).date()

        balance = float(starting_balance)

        extra_payments = extra_payments or []

        timeline = []

        for day in range(days + 1):

            current_date = (
                start_date +
                timedelta(days=day)
            )

            # ------------------------------------------------
            # Normal transactions
            # ------------------------------------------------

            if not transactions.empty:

                todays_events = transactions[
                    transactions["date"] == current_date
                ]

                for _, event in todays_events.iterrows():

                    amount = event.get("amount")

                    if pd.notna(amount):

                        balance += float(amount)

            # ------------------------------------------------
            # Candidate payments
            # ------------------------------------------------

            for payment in extra_payments:

                payment_date = payment["date"]

                if payment_date == current_date:

                    balance -= float(
                        payment["amount"]
                    )

            timeline.append({
                "date": current_date,
                "balance": round(balance, 2)
            })

        return timeline

    def is_safe(self, timeline):

        return all(
            row["balance"] >= self.minimum_balance
            for row in timeline
        )


# ============================================================
# SAFE AMOUNT TODAY
# ============================================================

def find_safe_amount_today(
    request_date,
    requested_amount,
    starting_balance,
    transactions,
    forecaster
):

    requested_amount = float(
        requested_amount
    )

    # First check whether full amount is safe
    full_payment = [{
        "date": request_date,
        "amount": requested_amount
    }]

    timeline = forecaster.simulate(
        start_date=request_date,
        starting_balance=starting_balance,
        transactions=transactions,
        extra_payments=full_payment
    )

    if forecaster.is_safe(timeline):

        return round(
            requested_amount,
            2
        )

    # --------------------------------------------------------
    # Binary search for maximum safe amount
    # --------------------------------------------------------

    low = 0.0
    high = requested_amount

    for _ in range(50):

        mid = (low + high) / 2

        payment = [{
            "date": request_date,
            "amount": mid
        }]

        timeline = forecaster.simulate(
            start_date=request_date,
            starting_balance=starting_balance,
            transactions=transactions,
            extra_payments=payment
        )

        if forecaster.is_safe(timeline):

            low = mid

        else:

            high = mid

    return round(low, 2)


# ============================================================
# CHECK PAYMENT PLAN
# ============================================================

def check_payment_plan(
    request_date,
    starting_balance,
    transactions,
    payments,
    forecaster
):

    timeline = forecaster.simulate(
        start_date=request_date,
        starting_balance=starting_balance,
        transactions=transactions,
        extra_payments=payments
    )

    return forecaster.is_safe(timeline)


# ============================================================
# FIND EARLIEST FULL PAYMENT DATE
# ============================================================

def find_earliest_full_payment_date(
    request_date,
    requested_amount,
    starting_balance,
    transactions,
    forecaster,
    desired_completion_date
):

    request_date = pd.to_datetime(
        request_date
    ).date()

    desired_completion_date = pd.to_datetime(
        desired_completion_date
    ).date()

    current_date = request_date

    while current_date <= desired_completion_date:

        payment = [{
            "date": current_date,
            "amount": requested_amount
        }]

        if check_payment_plan(
            request_date,
            starting_balance,
            transactions,
            payment,
            forecaster
        ):

            return current_date

        current_date += timedelta(days=1)

    return None


# ============================================================
# INSTALLMENT SCHEDULE
# ============================================================

def build_installment_schedule(option):

    payments = []

    start = pd.to_datetime(
        option["first_payment_date"]
    ).date()

    payment_count = int(
        option["number_of_payments"]
    )

    interval = int(
        option["payment_interval_days"]
    )

    total = float(
        option["total_payable_amount"]
    )

    # Divide total into equal installments
    base_amount = round(
        total / payment_count,
        2
    )

    # Handle rounding difference
    amounts = [
        base_amount
        for _ in range(payment_count)
    ]

    difference = round(
        total - sum(amounts),
        2
    )

    amounts[-1] = round(
        amounts[-1] + difference,
        2
    )

    for i in range(payment_count):

        payment_date = (
            start +
            timedelta(days=i * interval)
        )

        payments.append({
            "date": payment_date,
            "amount": amounts[i]
        })

    return payments


# ============================================================
# FORMAT PAYMENT PLAN
# ============================================================

def format_payment_plan(payments):

    if not payments:
        return "none"

    payments = sorted(
        payments,
        key=lambda x: x["date"]
    )

    return "|".join(
        f"{p['date']}:{p['amount']:.2f}"
        for p in payments
    )


# ============================================================
# PLAN SCORING
# ============================================================

def plan_score(plan):

    return (
        0 if plan["completes_by_deadline"] else 1,
        len(plan["spending_changes"]),
        plan["total_paid"],
        plan["first_payment_date"],
        len(plan["payments"]),
        str(plan.get("payment_option_id", ""))
    )


# ============================================================
# CREATE SIMPLE PAYMENT PLAN
# ============================================================

def create_full_payment_plan(
    request_date,
    requested_amount
):

    return [{
        "date": request_date,
        "amount": round(
            float(requested_amount),
            2
        )
    }]


# ============================================================
# PROCESS ONE REQUEST
# ============================================================

def process_request(
    request,
    loader
):

    request_id = request["request_id"]
    user_id = request["user_id"]

    request_date = pd.to_datetime(
        request["request_date"]
    ).date()

    desired_date = pd.to_datetime(
        request["desired_completion_date"]
    ).date()

    requested_amount = float(
        request["requested_amount"]
    )

    # --------------------------------------------------------
    # Get user's financial information
    # --------------------------------------------------------

    profile = loader.get_profile(user_id)

    if profile is None:

        return {
            "request_id": request_id,
            "amount_safe_to_pay": 0.0,
            "affordability_status": "not_affordable",
            "recommended_payment_method": "not_recommended",
            "payment_plan": "none",
            "earliest_date_for_full_payment": "",
            "spending_changes_needed": "none",
            "decision_explanation":
                "No financial profile was found."
        }

    events = prepare_events(
        loader.get_events(user_id)
    )

    # --------------------------------------------------------
    # Determine starting balance
    # --------------------------------------------------------

    balance_column = None

    for column in [
        "current_balance",
        "balance",
        "starting_balance"
    ]:

        if column in profile.index:

            balance_column = column
            break

    if balance_column is None:

        starting_balance = 0.0

    else:

        starting_balance = float(
            profile[balance_column]
        )

    # --------------------------------------------------------
    # Minimum preferred balance
    # --------------------------------------------------------

    minimum_balance = 0.0

    for column in [
        "minimum_balance",
        "preferred_minimum_balance",
        "minimum_preferred_balance"
    ]:

        if column in profile.index:

            value = profile[column]

            if pd.notna(value):

                minimum_balance = float(value)

            break

    forecaster = BalanceForecaster(
        minimum_balance
    )

    # --------------------------------------------------------
    # Calculate maximum safe payment today
    # --------------------------------------------------------

    safe_amount = find_safe_amount_today(
        request_date=request_date,
        requested_amount=requested_amount,
        starting_balance=starting_balance,
        transactions=events,
        forecaster=forecaster
    )

    # --------------------------------------------------------
    # Check whether full amount can be paid today
    # --------------------------------------------------------

    full_payment = create_full_payment_plan(
        request_date,
        requested_amount
    )

    full_payment_safe = check_payment_plan(
        request_date,
        starting_balance,
        events,
        full_payment,
        forecaster
    )

    # --------------------------------------------------------
    # AFFORDABLE NOW
    # --------------------------------------------------------

    if full_payment_safe:

        return {
            "request_id": request_id,
            "amount_safe_to_pay": round(
                requested_amount,
                2
            ),
            "affordability_status":
                "affordable_now",
            "recommended_payment_method":
                "full_payment",
            "payment_plan":
                format_payment_plan(
                    full_payment
                ),
            "earliest_date_for_full_payment":
                str(request_date),
            "spending_changes_needed":
                "none",
            "decision_explanation":
                "The requested amount can be paid now while maintaining the required minimum balance over the forecast period."
        }

    # --------------------------------------------------------
    # FIND EARLIEST SAFE FULL PAYMENT DATE
    # --------------------------------------------------------

    earliest_date = find_earliest_full_payment_date(
        request_date=request_date,
        requested_amount=requested_amount,
        starting_balance=starting_balance,
        transactions=events,
        forecaster=forecaster,
        desired_completion_date=desired_date
    )

    # --------------------------------------------------------
    # AFFORDABLE LATER
    # --------------------------------------------------------

    if earliest_date is not None:

        payment = [{
            "date": earliest_date,
            "amount": requested_amount
        }]

        return {
            "request_id": request_id,
            "amount_safe_to_pay":
                round(safe_amount, 2),
            "affordability_status":
                "affordable_later",
            "recommended_payment_method":
                "wait",
            "payment_plan":
                format_payment_plan(payment),
            "earliest_date_for_full_payment":
                str(earliest_date),
            "spending_changes_needed":
                "none",
            "decision_explanation":
                f"The full amount is not safe today, but becomes safe on {earliest_date} without changing recurring spending."
        }

    # --------------------------------------------------------
    # NOT AFFORDABLE
    # --------------------------------------------------------

    return {
        "request_id": request_id,
        "amount_safe_to_pay":
            round(safe_amount, 2),
        "affordability_status":
            "not_affordable",
        "recommended_payment_method":
            "not_recommended",
        "payment_plan":
            "none",
        "earliest_date_for_full_payment":
            "",
        "spending_changes_needed":
            "none",
        "decision_explanation":
            "The requested amount cannot be safely completed within the available forecast period while maintaining the required minimum balance."
    }


# ============================================================
# MAIN
# ============================================================

def main():

    print("Loading dataset...")

    loader = DataLoader()

    print(
        f"Loaded {len(loader.requests)} requests."
    )

    results = []

    for index, request in loader.requests.iterrows():

        print(
            f"Processing {index + 1}/"
            f"{len(loader.requests)}: "
            f"{request['request_id']}"
        )

        try:

            result = process_request(
                request,
                loader
            )

        except Exception as error:

            print(
                f"ERROR processing "
                f"{request['request_id']}: "
                f"{error}"
            )

            result = {
                "request_id":
                    request["request_id"],
                "amount_safe_to_pay": 0.0,
                "affordability_status":
                    "not_affordable",
                "recommended_payment_method":
                    "not_recommended",
                "payment_plan":
                    "none",
                "earliest_date_for_full_payment":
                    "",
                "spending_changes_needed":
                    "none",
                "decision_explanation":
                    f"Processing error: {error}"
            }

        results.append(result)

    # --------------------------------------------------------
    # Create output
    # --------------------------------------------------------

    output_df = pd.DataFrame(
        results
    )

    output_df = output_df[
        OUTPUT_COLUMNS
    ]

    output_df.to_csv(
        OUTPUT_FILE,
        index=False
    )

    print()
    print("=" * 60)
    print("DONE")
    print("=" * 60)
    print(
        f"Output saved to: {OUTPUT_FILE}"
    )


if __name__ == "__main__":
    main()